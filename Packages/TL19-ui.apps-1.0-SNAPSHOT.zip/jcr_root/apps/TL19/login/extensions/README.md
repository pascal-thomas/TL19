Extensions
==========

If you need to extend the login functionality, add a clientlibrary below this directory and give it the category `granite.core.login.extension`.
